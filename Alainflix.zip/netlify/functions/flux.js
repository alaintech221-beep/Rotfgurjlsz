const chromium = require('@sparticuz/chromium');
const puppeteer = require('puppeteer-core');

const SOURCES = {
  france4: "https://www.stream4free.tv/france-4",
};

const cache = {};

function chercher(texte) {
  if (!texte) return null;
  const variantes = [texte];
  variantes.push(texte.replace(/\\\//g, "/").replace(/\\u0026/g, "&").replace(/&amp;/g, "&"));
  try { variantes.push(decodeURIComponent(variantes[1])); } catch (e) {}

  for (const v of variantes) {
    const m = v.match(/https?:\/\/[^\s"'<>\\()]+?\.m3u8[^\s"'<>\\()]*/i);
    if (m) return m[0];
  }
  return null;
}

exports.handler = async (event) => {
  const id = (event.queryStringParameters || {}).id;
  const pageUrl = SOURCES[id];
  if (!pageUrl) return rep(404, { erreur: "Chaîne inconnue : " + id });

  const c = cache[id];
  if (c && Date.now() - c.t < 60000) {
    return rep(200, { url: c.url });
  }

  let browser = null;
  try {
    browser = await puppeteer.launch({
      args: chromium.args,
      defaultViewport: chromium.defaultViewport,
      executablePath: await chromium.executablePath(),
      headless: chromium.headless,
      ignoreHTTPSErrors: true,
    });

    const page = await browser.newPage();
    await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36");

    let foundUrl = null;

    page.on('request', (request) => {
      const reqUrl = request.url();
      if (reqUrl.includes('.m3u8')) {
        foundUrl = reqUrl;
      }
    });

    await page.goto(pageUrl, { waitUntil: 'networkidle2', timeout: 30000 });

    if (!foundUrl) {
      const content = await page.content();
      foundUrl = chercher(content);
    }

    await browser.close();

    if (!foundUrl) {
      return rep(404, { erreur: "Aucun lien m3u8 trouvé via Puppeteer." });
    }

    cache[id] = { url: foundUrl, t: Date.now() };
    return rep(200, { url: foundUrl });

  } catch (e) {
    if (browser) await browser.close();
    return rep(502, { erreur: String(e.message || e) });
  }
};

function rep(code, obj) {
  return { statusCode: code, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify(obj) };
}